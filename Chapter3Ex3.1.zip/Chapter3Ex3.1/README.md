Exercise 2.1 Invoice Total Form
